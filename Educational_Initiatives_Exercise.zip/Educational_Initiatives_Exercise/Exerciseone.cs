using System;
using System.Collections.Generic;

#region Behavioral Patterns

// 1. Strategy Pattern: Different Content Delivery Strategies
public interface IContentDeliveryStrategy {
    void DeliverContent(string courseName);
}

public class VideoDelivery : IContentDeliveryStrategy {
    public void DeliverContent(string courseName) {
        Console.WriteLine($"Delivering video content for course: {courseName}");
    }
}

public class TextDelivery : IContentDeliveryStrategy {
    public void DeliverContent(string courseName) {
        Console.WriteLine($"Delivering text content for course: {courseName}");
    }
}

public class QuizDelivery : IContentDeliveryStrategy {
    public void DeliverContent(string courseName) {
        Console.WriteLine($"Delivering quiz content for course: {courseName}");
    }
}

// Context class to manage content delivery
public class CourseContentContext {
    private IContentDeliveryStrategy _strategy;

    public void SetDeliveryStrategy(IContentDeliveryStrategy strategy) {
        _strategy = strategy;
    }

    public void DeliverContent(string courseName) {
        _strategy.DeliverContent(courseName);
    }
}

// 2. Observer Pattern: Users subscribing to course updates
public interface IObserver {
    void Update(string courseUpdate);
}

public class User : IObserver {
    private string _name;
    public User(string name) {
        _name = name;
    }

    public void Update(string courseUpdate) {
        Console.WriteLine($"{_name} received course update: {courseUpdate}");
    }
}

public interface ISubject {
    void RegisterObserver(IObserver observer);
    void RemoveObserver(IObserver observer);
    void NotifyObservers(string update);
}

public class Course : ISubject {
    private List<IObserver> _observers = new List<IObserver>();
    private string _courseName;

    public Course(string courseName) {
        _courseName = courseName;
    }

    public void RegisterObserver(IObserver observer) {
        _observers.Add(observer);
    }

    public void RemoveObserver(IObserver observer) {
        _observers.Remove(observer);
    }

    public void NotifyObservers(string update) {
        foreach (var observer in _observers) {
            observer.Update(update);
        }
    }

    public void NewUpdate(string update) {
        Console.WriteLine($"Course {_courseName} has a new update: {update}");
        NotifyObservers(update);
    }
}

#endregion

#region Creational Patterns

// 3. Factory Pattern: Creating different types of course materials
public abstract class CourseMaterial {
    public abstract void ShowMaterial();
}

public class VideoMaterial : CourseMaterial {
    public override void ShowMaterial() {
        Console.WriteLine("Displaying Video Material.");
    }
}

public class ArticleMaterial : CourseMaterial {
    public override void ShowMaterial() {
        Console.WriteLine("Displaying Article Material.");
    }
}

public class QuizMaterial : CourseMaterial {
    public override void ShowMaterial() {
        Console.WriteLine("Displaying Quiz Material.");
    }
}

public class MaterialFactory {
    public CourseMaterial CreateMaterial(string type) {
        switch (type) {
            case "video":
                return new VideoMaterial();
            case "article":
                return new ArticleMaterial();
            case "quiz":
                return new QuizMaterial();
            default:
                throw new Exception("Unknown material type.");
        }
    }
}

// 4. Singleton Pattern: Course Manager
public class CourseManager {
    private static CourseManager _instance;

    private CourseManager() { }

    public static CourseManager GetInstance() {
        if (_instance == null) {
            _instance = new CourseManager();
        }
        return _instance;
    }

    public void ManageCourse(string courseName) {
        Console.WriteLine($"Managing course: {courseName}");
    }
}

#endregion

#region Structural Patterns

// 5. Adapter Pattern: Adapting legacy PDF content into the modern platform
public class LegacyPDFContent {
    public void ShowPDF() {
        Console.WriteLine("Showing legacy PDF content.");
    }
}

public interface INewContent {
    void Display();
}

public class PDFAdapter : INewContent {
    private LegacyPDFContent _legacyPDFContent;

    public PDFAdapter(LegacyPDFContent legacyPDFContent) {
        _legacyPDFContent = legacyPDFContent;
    }

    public void Display() {
        _legacyPDFContent.ShowPDF();
    }
}

// 6. Decorator Pattern: Adding features to courses
public interface ICourse {
    void DescribeCourse();
}

public class BasicCourse : ICourse {
    public void DescribeCourse() {
        Console.WriteLine("This is a basic course.");
    }
}

public class CourseDecorator : ICourse {
    protected ICourse _course;

    public CourseDecorator(ICourse course) {
        _course = course;
    }

    public virtual void DescribeCourse() {
        _course.DescribeCourse();
    }
}

public class CertificateDecorator : CourseDecorator {
    public CertificateDecorator(ICourse course) : base(course) { }

    public override void DescribeCourse() {
        base.DescribeCourse();
        Console.WriteLine("Includes downloadable certificate.");
    }
}

#endregion

public class Program {
    public static void Main(string[] args) {
        // Behavioral: Strategy Pattern - Different content delivery methods
        CourseContentContext contentContext = new CourseContentContext();
        contentContext.SetDeliveryStrategy(new VideoDelivery());
        contentContext.DeliverContent("C# Programming");

        contentContext.SetDeliveryStrategy(new TextDelivery());
        contentContext.DeliverContent("C# Programming");

        // Behavioral: Observer Pattern - Users subscribing to course updates
        Course course = new Course("Java Programming");
        User user1 = new User("Alice");
        User user2 = new User("Bob");

        course.RegisterObserver(user1);
        course.RegisterObserver(user2);
        course.NewUpdate("New lesson added!");

        // Creational: Factory Pattern - Creating different course materials
        MaterialFactory materialFactory = new MaterialFactory();
        CourseMaterial material = materialFactory.CreateMaterial("video");
        material.ShowMaterial();

        material = materialFactory.CreateMaterial("article");
        material.ShowMaterial();

        // Creational: Singleton Pattern - Managing courses
        CourseManager manager = CourseManager.GetInstance();
        manager.ManageCourse("Python Programming");

        // Structural: Adapter Pattern - Adapting legacy PDF content
        LegacyPDFContent legacyPDF = new LegacyPDFContent();
        INewContent newContent = new PDFAdapter(legacyPDF);
        newContent.Display();

        // Structural: Decorator Pattern - Adding course features
        ICourse basicCourse = new BasicCourse();
        ICourse certificateCourse = new CertificateDecorator(basicCourse);
        certificateCourse.DescribeCourse();
    }
}





#region Explanation of Key Concepts and Design Choices

// 1. Strategy Pattern (Behavioral):
//    - The Strategy Pattern allows the selection of different content delivery methods (video, text, quiz) at runtime.
//    - This keeps the system flexible by allowing the content delivery strategy to change without altering the core logic.
//    - Example: The `CourseContentContext` uses the `IContentDeliveryStrategy` interface to apply different strategies for content delivery.

// 2. Observer Pattern (Behavioral):
//    - The Observer Pattern is used to notify users (observers) when there is a course update.
//    - It allows users to subscribe to a course and receive notifications when the course content is updated.
//    - Example: The `Course` class maintains a list of observers (users) and sends updates to them when new content is available.

// 3. Factory Pattern (Creational):
//    - The Factory Pattern is used to create different types of course materials (video, article, quiz) based on the input.
//    - It abstracts the process of creating course materials, making the system more maintainable and extendable.
//    - Example: The `MaterialFactory` class creates instances of `CourseMaterial` subclasses based on the type requested.

// 4. Singleton Pattern (Creational):
//    - The Singleton Pattern ensures that only one instance of `CourseManager` exists, which manages the courses.
//    - This is useful when exactly one object is needed to coordinate actions in a system.
//    - Example: The `CourseManager` class follows the Singleton pattern, ensuring only one manager instance handles the courses.

// 5. Adapter Pattern (Structural):
//    - The Adapter Pattern is used to integrate legacy systems (like PDF content) into modern applications.
//    - It allows incompatible interfaces to work together by creating an adapter that translates requests.
//    - Example: The `PDFAdapter` adapts the `LegacyPDFContent` so it can be used with the `INewContent` interface.

// 6. Decorator Pattern (Structural):
//    - The Decorator Pattern allows the addition of new functionality (like certificates) to an existing object (course) dynamically.
//    - This pattern is useful for enhancing functionality without modifying the original class.
//    - Example: The `CertificateDecorator` adds a feature to a basic course, allowing it to include a downloadable certificate.

#endregion